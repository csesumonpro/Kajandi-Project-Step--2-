<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CustomerReview extends Model{

}
