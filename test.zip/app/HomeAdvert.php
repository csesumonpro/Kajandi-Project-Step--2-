<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class HomeAdvert extends Model
{
    //
}
